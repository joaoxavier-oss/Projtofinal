

const scriptsInEvents = {

	async Folhaglobal_Event8_Act3(runtime, localVars)
	{
		
	}
};

globalThis.C3.JavaScriptInEvents = scriptsInEvents;
